import React, { useState } from 'react';
import rooms from '../data/rooms.json';
import predictNextMove from '../lib/predictor';

export default function Home() {
  const [selectedRoom, setSelectedRoom] = useState('A');
  const result = predictNextMove(rooms[selectedRoom]);

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>✅ เฮียปั้น - สูตรบาคาร่า AI เซ็กซี่บาคาร่า</h1>
      <label>
        เลือกห้อง:
        <select onChange={(e) => setSelectedRoom(e.target.value)} value={selectedRoom}>
          {Object.keys(rooms).map(room => (
            <option key={room} value={room}>{room}</option>
          ))}
        </select>
      </label>
      <h2>คำแนะนำ: {result.recommendation}</h2>
      <p>ความมั่นใจ: {result.confidence}%</p>
    </div>
  );
}
