import React from 'react';

export default function Admin() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>🔐 แอดมิน - จัดการข้อมูลสูตร</h1>
      <p>Coming soon...</p>
    </div>
  );
}
